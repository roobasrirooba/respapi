package com.rooba.vechileapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VechileappApplicationTests {

	@Test
	void contextLoads() {
	}

}
