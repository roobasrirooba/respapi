package com.rooba.vechileapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VechileappApplication {

	public static void main(String[] args) {
		SpringApplication.run(VechileappApplication.class, args);
	}

}
